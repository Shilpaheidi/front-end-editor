export interface Description {
    bold: boolean;
    italic: boolean;
    hyperlink: string;
    // Add other fields as needed
  }
  